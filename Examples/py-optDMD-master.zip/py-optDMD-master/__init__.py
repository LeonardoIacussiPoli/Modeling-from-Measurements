# outer __init__.py

from optimalDMD import optdmd